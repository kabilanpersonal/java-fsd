
public class Stack_insert_and_remove {
	static final int MAX=1000;
	   int top;
	   int a[]=new int[MAX];
	   
	   boolean isEmpty() {
		   return top<0;
	   }
	   
	   public Stack_insert_and_remove() {
		   top=-1;//default stack an empty
	   }
	   
	   boolean push(int x) {
		   if(top>=(MAX-1)) {
			   System.out.println("Stack over flow");
			   return false;
		   }
		   else {
			   a[++top]=x;
			   System.out.println(x+" Pushed into stack");
			   return true;
		   }
	   }
	   int pop() {
		   if(top<0) {
			   System.out.println("Stack under flow");
			   return 0;
		   }
		   else {
			   int x=a[top--];
			   return x;
		   }
	   }
	   
	   public static void main(String args[]) {
		   Stack_insert_and_remove s=new Stack_insert_and_remove();
		   s.push(100);
		   s.push(11);
		   s.push(41);
		   s.push(97);
		   
	      System.out.println(s.pop()+" Poped out from stack");
		   
	   }
}
