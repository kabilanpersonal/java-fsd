
public class Creating_thread1  extends Thread{  
	public void run(){  
		System.out.println("Java Thread Creation by extending Thread class");  
		}  
		public static void main(String args[]){  
			Creating_thread1 t1=new Creating_thread1();  
		t1.start();  
		 }  
		}  