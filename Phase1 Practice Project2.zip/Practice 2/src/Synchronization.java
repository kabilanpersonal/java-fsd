
public class Synchronization {
		public static void main(String[] args) {
			
			Sender sender = new  Sender();
			
			User t1= new User("Raju ", "Hello Good morning....!", sender);
			User t2= new User("Bheem ","Hii!! how  are you?",sender);
			
			t1.start();
			t2.start();
		}

}
