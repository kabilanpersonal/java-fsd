package assistedPractice5;

public class ThrowDemo2 {
	void total() throws ArithmeticException{
        int a=10,b=0;
        int sum=a/b;
        System.out.println("sum is: "+sum);
    }
   public static void main(String args[]) {
     	
        ThrowDemo2 td=new ThrowDemo2();
        
         try {
        	 td.total(); 
         }
         catch(Exception e) {
        	System.out.println("\nError: "+e.getMessage());
         }
        
    }
}
