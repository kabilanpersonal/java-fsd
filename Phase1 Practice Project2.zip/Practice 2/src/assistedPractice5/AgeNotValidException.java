package assistedPractice5;

public class AgeNotValidException extends Exception {
	       private String msg;

		AgeNotValidException(String msg) {
			this.msg = msg;
		}

		public String toString() {
			return "AgeNotValidException [msg=" + msg + "]";
		}
	       
	}
