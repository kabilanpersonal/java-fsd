package assistedPractice5;

public class customException {
	
	  public static void main(String args[]) {
		  try {
			  System.out.println("Starting the try block");
			  //throwing the custom exception using try block
			  throw new MyException("This is my error msg");
		  }
		  catch(MyException e) {
			  System.out.println("Catch block");
			  System.out.println(e);
		  }
	  }
}
