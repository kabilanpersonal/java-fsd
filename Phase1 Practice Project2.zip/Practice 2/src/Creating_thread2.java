
public class Creating_thread2  implements Runnable{  
	public void run(){  
		System.out.println("Java Thread Creation by implementing Runnable interface");  
		}  
		  
		public static void main(String args[]){  
			 Creating_thread2 m1=new  Creating_thread2();  
		Thread t1 =new Thread(m1); 
		t1.start();  
		 }  
		}  

