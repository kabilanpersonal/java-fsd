
	interface DemoInterface  
	{   
	//default method   
	default void display()   
	{   
	System.out.println("The dispaly() method invoked");   
	}   
	}   
	//interface without default method  
	interface DemoInterface1 extends DemoInterface  
	{   
	      
	}   
	//interface without default method  
	interface DemoInterface2 extends DemoInterface  
	{  
	      
	}    

	public class DiamondProblem implements DemoInterface1, DemoInterface2  {
		public static void main(String args[])   
		{   
		DiamondProblem obj = new DiamondProblem();   
		//calling method  
		obj.display();   
		}   
	}
