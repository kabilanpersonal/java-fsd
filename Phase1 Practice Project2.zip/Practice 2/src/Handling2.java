
public class Handling2 {
public static void main(String[] args) {
		
		
		int a=2;
		int b=0;
		
		
		try {
			int c=a/b;
			System.out.println("Result is: "+c);
			
		} catch (ArithmeticException e) {
			System.out.println("Error: "+e);
		}
		
	}
}
