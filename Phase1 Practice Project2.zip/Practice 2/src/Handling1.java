
public class Handling1 {

	public static void main(String[] args) {
		 
				String a="r";
				int number;
					try {
						number=Integer.parseInt(a);
						System.out.println("Number is "+number);
					}
					catch (Exception e) {
						System.out.println("Exception Occured: "+e);
					}
	}
}
