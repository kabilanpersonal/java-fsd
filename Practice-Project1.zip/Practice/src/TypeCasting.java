
public class TypeCasting{
	public static void main(String[] args) {
		System.out.println("Implicit TypeCasting Or Widening");
		char a= 'K';
		int b=a;
		System.out.println("a value = "+ a);
		System.out.println("b value = "+ b);
		System.out.println("\n");
		System.out.println("Explicit Typecasting Or Narrowing");
		int c =90;
		char d = (char) c;
		System.out.println("c value = "+ c);
		System.out.println("d value = "+ d);
		
	}
}
